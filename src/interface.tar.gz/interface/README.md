### index.py
### config dir: include some basic config included(ErrorStatus, settings, etc)
### common dir: some functions
### api dir: public api included login, isRight, getFinalScore

### db: redis mysql
