#!/usr/bin/env python
# coding=utf-8

HOSTNAME = '127.0.0.1'
DATABASE = 'QA_game'
USERNAME = 'houyf'
PASSWORD = 'Beyond'
