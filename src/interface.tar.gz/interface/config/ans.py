#!/usr/bin/env python
# coding=utf-8
PINTU_ANS =[
    '429165873',
    '163725489',
    '153729486',
    '463725819',
]
