#! /usr/bin/env python
# encoding: utf-8

import sys
sys.append('.')
