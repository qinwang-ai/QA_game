#!/bin/bash

mysqldump -uhouyf -pBeyond QA_game > QA_game_data.sql
