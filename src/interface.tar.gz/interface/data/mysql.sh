#!/bin/bash

mysql -uhouyf -pBeyond QA_game < QA_game_scheme.sql
